void makeSearch(String value) {
  print("A research made for key word $value");
  
}
