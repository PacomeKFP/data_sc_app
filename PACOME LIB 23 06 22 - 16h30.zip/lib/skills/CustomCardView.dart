import 'package:flutter/material.dart';

class CustomCardView {
  final String title;
  final String description;
  final String image;
  CustomCardView({this.title = "", this.description = "", this.image = ""});
  Card cardview(BuildContext context) {
    return Card(
      elevation: 10,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            GestureDetector(
              child: Center(
                  child: Column(children: [
                Text(
                  this.title,
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent),
                ),
                SizedBox(
                  height: 3,
                  width: 3,
                ),
                Image.asset(this.image,
                    width: 300, height: 300, fit: BoxFit.fill),
                SizedBox(
                  height: 3,
                  width: 3,
                ),
                Text(
                  "Description",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent),
                ),
                SizedBox(
                  height: 3,
                  width: 3,
                ),
                Text(this.description),
              ])),

              onTap: () {
                //Implementer diriger vers la page de presentation du cours
              },
            )
          ],
        ),
      ),
    );
  }
}
