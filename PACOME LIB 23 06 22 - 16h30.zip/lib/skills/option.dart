import 'package:flutter/material.dart';
// import 'package:test1/screen/authentification/register.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'CustomCardView.dart';
// import 'dart:ui' as ui;
// import 'package:test1/images/';
// import 'package:http/http.dart' as http;
// import 'package:test1/widgets/custom%20TextField.dart';

class Option extends StatefulWidget {
  // final VoidCallback visible;
  // Option(this.visible);
  @override
  _OptionState createState() => _OptionState();
}

class _OptionState extends State<Option> {
  CustomCardView vue1 = new CustomCardView(
    title: "Product Owner",
    description: "Ce module est tres important",
    image: "../../assets/images/1.jpg",
  );
  CustomCardView vue2 = new CustomCardView(
    title: "Data Mining",
    description: "Ce module est tres important",
    image: "../../assets/images/2.jpg",
  );
  CustomCardView vue3 = new CustomCardView(
    title: "Data Analyst",
    description: "Ce module est tres important",
    image: "../../assets/images/3.jpg",
  );
  CustomCardView vue4 = new CustomCardView(
    title: "Data Engeneer",
    description: "Ce module est tres important",
    image: "images/4.jpg",
  );
  CustomCardView vue5 = new CustomCardView(
    title: "Big Data",
    description: "Ce module est tres important",
    image: "images/5.jpg",
  );
  CustomCardView vue6 = new CustomCardView(
    title: "Data Base",
    description: "Ce module est tres important",
    image: "images/6.jpg",
  );
  @override
  Widget build(BuildContext context) {
    // Size get screenSize => (ui.window.physicalSize / ui.window.devicePixelRatio);
    // double width = MediaQuery.of(context).size.width;
    // double height = MediaQuery.of(context).size.height;
    return Container(
      //       child: Padding(
      padding: EdgeInsets.all(16.0),
      child: Center(
        child: SingleChildScrollView(
          child: Row(
            children: [
              vue1.cardview(context),
              vue2.cardview(context),
              vue3.cardview(context),
            ],
          ),
          // child: Row(
          //   children: [
          //     vue4.cardview(context),
          //     vue5.cardview(context),
          //     vue6.cardview(context),
          //   ],
          // )
        ),
      ),
    );

  }

  
}
