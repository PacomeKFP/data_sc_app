import 'package:flutter/cupertino.dart';

class Course {
  final String title, syllabus, prix;
  final DateTime debut;
  final int progression;
  Course(this.syllabus, this.prix, this.debut, this.progression,
      {required this.title});

  Widget getCourse({required BuildContext context}) {
    return Container(
      child: Text("Cours: $title"),
    );
  }
}
